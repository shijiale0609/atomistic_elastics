.. _License-information:

Copyright
=========

SSAGES Copyright 2016 University of Chicago, University of Notre Dame. All Rights Reserved. 

License information
===================

SSAGES is distributed under the GNU Lesseer General Public License either version 3 or (at your
option) any later version (LGPLv3). The full terms of the LGPLv3 can be found on
the `GNU LGPL homepage <https://www.gnu.org/licenses/lgpl-3.0.html>`_. You are free to
modify and redistribute this software under the terms of the GNU Lesser General Public
License.

The documentation is distributed under the terms of Creative Commons 4.0 BY-SA.
This means you are free to share and adapt the documentation as long as you give
credit to the original authors and release your derivative work under the same
license. The full license can be found `here
<https://creativecommons.org/licenses/by-sa/4.0/legalcode>`_.

Contributors to the documentation (in alphabetical order):

* Cody Bezik
* Yamil J. Colón
* Grant Garner
* Ashley Guo
* Julian Helfferich
* Joshua Lequieu
* Jiyuan Li
* Joshua Moller
* Hadi Ramezani-Dakhel
* Ben Sikora
* Emre Sevgen
* Hythem Sidky
