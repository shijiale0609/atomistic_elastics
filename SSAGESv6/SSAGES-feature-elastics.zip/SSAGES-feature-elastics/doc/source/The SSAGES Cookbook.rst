The SSAGES cookbook
===================

A collection of short solutions to common problems. Just like a FAQ.
