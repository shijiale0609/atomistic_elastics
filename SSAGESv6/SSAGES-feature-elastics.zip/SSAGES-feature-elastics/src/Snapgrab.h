#pragma once 

#include "Snapshot.h"

namespace SSAGES
{
    class Snapgrab 
    {
    private:
		// Current iteration.
		unsigned iteration_; 

		// Boost communicator.
		boost::mpi::communicator _comm;

		std::vector<Vector3> positions_; //!< Positions 
		std::vector<double> masses_; //!< Masses
		Label atomids_; //!< List of Atom IDs 
		Label id2idx_; //!< ID to index map.

		Matrix3 _H; //!< Parrinello-Rahman box H-matrix.
		Matrix3 _Hinv; //!< Parinello-Rahman box inverse.
		bool ortho_; //!< Is box orthorhombic?

		Vector3 _origin; //!< Box origin.

		Bool3 _isperiodic; //!< Periodicity of box.
		
		//! Determines if the box is orthorhombic.
		void SetOrthorhombic()
		{
			auto tol = 1.e-6*_H.diagonal().minCoeff();
			ortho_ = true;
			for(int i = 0; i < 3; ++i)
			{
				for(int j = 0; j < 3; ++j)
				{
					if(i != j)
					{
						if(std::abs(_H(i,j)) > tol)
							ortho_ = false;
					}
				}
			}
		}

		// Private constructor. 
		Snapgrab() : iteration_(-1) {}
	public: 
		// Get singleton instance of Snapgrab.
		static Snapgrab& Instance()
		{
			static Snapgrab instance; 
			return instance;
		}

		void SyncSnapshot(const Snapshot& snapshot)
		{
			// Do nothing if we have already sync'ed this snapshot.
			if(snapshot.GetIteration() == iteration_)
				return;
			
			// Sync box info. 
			_H = snapshot.GetHMatrix();
			_Hinv = _H.inverse();
			_isperiodic = snapshot.IsPeriodic();
			SetOrthorhombic();

			// Reduce all atom information.
			auto natoms = snapshot.GetNumAtoms();
			auto& pos = snapshot.GetPositions();
			auto& mass = snapshot.GetMasses();
			auto& ids = snapshot.GetAtomIDs();
			auto& comm = snapshot.GetCommunicator();
			
			// Local and global variables. 
			std::vector<double> lpos(3*natoms, 0), gpos, lmass(natoms, 0);
			std::vector<int> lids(natoms, 0);

			// Scalar and vector counts/displacements. 
			std::vector<int> scounts(comm.size(), 0), vcounts(comm.size(), 0); 
			std::vector<int> sdisp(comm.size()+1, 0), vdisp(comm.size()+1, 0);

			scounts[comm.rank()] = natoms;
			vcounts[comm.rank()] = 3*natoms;

			// Reduce counts.
			MPI_Allreduce(MPI_IN_PLACE, scounts.data(), scounts.size(), MPI_INT, MPI_SUM, comm);
			MPI_Allreduce(MPI_IN_PLACE, vcounts.data(), vcounts.size(), MPI_INT, MPI_SUM, comm);

			// Compute displacements.
			std::partial_sum(scounts.begin(), scounts.end(), sdisp.begin() + 1);
			std::partial_sum(vcounts.begin(), vcounts.end(), vdisp.begin() + 1);

			// Fill up vectors.
			for(int i = 0; i < natoms; ++i)
			{
				lpos[3*i] = pos[i][0]; 
				lpos[3*i+1] = pos[i][1]; 
				lpos[3*i+2] = pos[i][2];
				lmass[i] = mass[i];
				lids[i] = ids[i]; 
			}

			// Resize receiving vectors. 
			gpos.resize(vdisp.back(), 0);
			positions_.resize(sdisp.back(), Vector3{0,0,0});
			masses_.resize(sdisp.back(), 0);
			atomids_.resize(sdisp.back(), 0);
			id2idx_.resize(sdisp.back(), -1);

			// All-gather data. 
			MPI_Allgatherv(lpos.data(), lpos.size(), MPI_DOUBLE, gpos.data(), vcounts.data(), vdisp.data(), MPI_DOUBLE, comm);
			MPI_Allgatherv(lmass.data(), lmass.size(), MPI_DOUBLE, masses_.data(), scounts.data(), sdisp.data(), MPI_DOUBLE, comm);
			MPI_Allgatherv(lids.data(), lids.size(), MPI_INT, atomids_.data(), scounts.data(), sdisp.data(), MPI_INT, comm);

			// Fill back up.
			for(int i = 0; i < sdisp.back(); ++i)
			{
				// Positions.
				positions_[i][0] = gpos[3*i];
				positions_[i][1] = gpos[3*i+1];
				positions_[i][2] = gpos[3*i+2];

				if(atomids_[i] > id2idx_.size() - 1)
					id2idx_.resize(atomids_[i] + 1, -1);
				id2idx_[atomids_[i]] = i;
			}

			// Set iteration. 
			iteration_ = snapshot.GetIteration();
		}

		//! Access the particle positions
		/*!
		 * \return List of particle positions
		 */
		const std::vector<Vector3>& GetPositions() const { return positions_; }
		
		//! Const access to the particle masses
		/*!
		 * \return List of Masses
		 */
		const std::vector<double>& GetMasses() const { return masses_; }

		//! Apply minimum image to a vector.
		/*!
		 * \param v Vector of interest
		 */
		void ApplyMinimumImage(Vector3* v) const
		{
			// General implementation.
			if(!ortho_)
			{
				Vector3 scaled = _Hinv*(*v);

				for(int i = 0; i < 3; ++i)
					scaled[i] -= _isperiodic[i]*roundf(scaled[i]);

				*v = _H*scaled;
			}
			else // Orthorhombic implementation.
			{
				double scaled = 0.;
				for(int i = 0; i < 3; ++i)
				{
					scaled = (*v)[i]*_Hinv(i,i);
					scaled -= _isperiodic[i]*roundf(scaled);
					(*v)[i] = scaled*_H(i,i);
				}
			}
		}
		
		//! Apply minimum image to a vector.
		/*!
		 * \param v Vector of interest
		 */
		Vector3 ApplyMinimumImage(const Vector3& v) const
		{
			// General implementation.
			if(!ortho_)
			{
				Vector3 scaled = _Hinv*v;

				for(int i = 0; i < 3; ++i)
					scaled[i] -= _isperiodic[i]*roundf(scaled[i]);

				return _H*scaled;	
			}
			else // Orthorhombic implementation.
			{
				Vector3 scaled = v.cwiseProduct(_Hinv.diagonal());
				for(int i = 0; i < 3; ++i)
				{
					scaled[i] -= _isperiodic[i]*roundf(scaled[i]);
					scaled[i] *= _H(i,i);
				}
				return scaled;
			}
		}

		//! Compute the total mass of a group of particles based on index. 
		/*!
		  * \param indices IDs of particles of interest. 
		  * \return double Total mass of particles. 
		 */
		double TotalMass(const Label& indices) const
		{
			auto mtot = 0.;
			for(auto& i : indices)
				mtot += masses_[i];
			return mtot;
		}

		//! Compute center of mass of a group of atoms based on idex with provided 
		//! Total mass.
		/*!
		  * \param indices IDs of particles of interest. 
		  * \return Vector3 Center of mass of particles.
		  */ 		
		Vector3 CenterOfMass(const Label& indices) const
		{
			// Get total mass.
			auto mtot = TotalMass(indices);

			return CenterOfMass(indices, mtot);			
		}

		//! Compute center of mass of a group of atoms based on idex with provided 
		//! Total mass.
		/*!
		  * \param indices IDs of particles of interest. 
		  * \param mtot Total mass of particle group. 
		  * \return Vector3 Center of mass of particles.
		  */ 
		Vector3 CenterOfMass(const Label& indices, double mtot) const
		{
			// Loop through atoms and compute mass weighted sum. 
			// We march linearly through list and find nearest image
			// to each successive particle to properly unwrap object.
			Vector3 ppos = positions_[indices[0]]; // Previous unwrapped position.
			Vector3 cpos = ppos;
			Vector3 xcm = masses_[indices[0]]*cpos;

			for(size_t i = 1; i < indices.size(); ++i)
			{
				cpos = positions_[indices[i]];
				cpos = ApplyMinimumImage(cpos - ppos) + ppos;
				xcm += masses_[indices[i]]*cpos;
				ppos = cpos;
			}

			return xcm/mtot;
		}

		//! Access the atom IDs
		/*!t
		 * \return List of atom IDs
		 */
		const Label& GetAtomIDs() const { return atomids_; }

		//! Gets the local atom index corresponding to an atom ID.
		/*!
		 * \param Atom ID. 
		 * \return Local atom index or -1 if not found.
		 */
		int GetLocalIndex(int id) const
		{
			if(id > id2idx_.size() - 1)
				return -1;
			
			return id2idx_[id];
		}

		//! Gets the local atom indices corresponding to atom IDs in the 
		//! vector.
		/*!
		 * \param ids Vector of atom ID's. 
		 * \param indices Pointer to container for local atom indices. 
		 *
		 * \note If atom does not exist on processor, it will be ignored. 
		 */
		void GetLocalIndices(const Label& ids, Label* indices) const
		{
			indices->reserve(ids.size());
			for(auto& id : ids)
			{
				auto idx = GetLocalIndex(id);
				if(idx != -1)
					indices->push_back(idx);
			}
		}
    };
}