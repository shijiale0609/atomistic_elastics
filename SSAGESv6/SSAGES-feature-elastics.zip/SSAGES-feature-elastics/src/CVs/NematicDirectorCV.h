/**
 * This file is part of
 * SSAGES - Suite for Advanced Generalized Ensemble Simulations
 *
 * Copyright 2016 Hythem Sidky <hsidky@nd.edu>
 *
 * SSAGES is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * SSAGES is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with SSAGES.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once 

#include "Drivers/DriverException.h"
#include "CollectiveVariable.h"
#include "Snapgrab.h"
#include <Eigen/Eigenvalues>

namespace SSAGES
{
	class NematicDirectorCV: public CollectiveVariable
	{
	private:
		//! Particle groups of interest.
		std::vector<Label> groups_;

		//! Reference director. 
		Vector3 d_;

		//! Restricted region or not? 
		bool restricted_; 

		//! Restricted dimension. 
		Dimension dim_;

		//! Restriction range. 
		double rmin_ = 0, rmax_ = 0;

		//! Use P2 objective function?
		bool p2_;

		// Vector of intermediate gradients.
		std::vector<Matrix3> gradient_;

		//! Check if coordinate lies within the restriction region. 
		bool IsWithinRegion(const Vector3& x)
		{
			if(!restricted_)
				return true;

			auto r = 0.;
			switch(dim_)
			{
				case Dimension::x:
					r = x[0];
					break;
				case Dimension::y:
					r = x[1];
					break;
				case Dimension::z:
					r = x[2];
					break;
			}

			// If rmin is larger than rmax, region crosses periodic boundary.
			if(rmin_ > rmax_ && (r <= rmax_ || r >= rmin_ ))
				return true;
			else if(r >= rmin_ && r <= rmax_)
				return true;

			return false;
		}

	public:
		//! Constructor. 
		/*! 
		 * \param groups Vector of vector (groups) of atom ID's, each group representing an 
		 *        individual particle. 
		 * \param director Reference orientational director.
		 */
		NematicDirectorCV(const std::vector<Label>& groups, const Vector3& director) : 
		groups_(groups), d_(director), restricted_(false), p2_(true), gradient_()
		{}
		
		//! Constructor with restriction region. Use of a restriction region will compute the 
		//  nematic director CV for particles falling within the specified region along the 
		//  specified dimension. If rmin > rmax, the region goes across periodic bounds.
		/*! 
		 * \param groups Vector of vector (groups) of atom ID's, each group representing an 
		 *        individual particle. 
		 * \param director Reference orientational director.
		 * \param dim Dimension (x,y,z) along which to apply a restriction.
		 * \param rmin Minimum position along dimension to include particles.
		 * \param rmax Maximum position along the dimension to include particles.
		 */
		NematicDirectorCV(
			const std::vector<Label>& groups, 
			const Vector3& director, 
			Dimension dim, 
			double rmin, 
			double rmax) : 
		groups_(groups), d_(director), restricted_(true), dim_(dim), 
		rmin_(rmin), rmax_(rmax), p2_(true), gradient_()
		{}
		
		//! Initialize necessary variables.
		/*!
		 * \param snapshot Current simulation snapshot.
		 */
		void Initialize(const Snapshot& snapshot) override
		{
			using std::to_string;

			for(size_t j = 0; j < groups_.size(); ++j)
			{
				auto n = groups_[j].size();

				// Make sure atom ID's are on at least one processor. 
				std::vector<int> found(n, 0);
				for(size_t i = 0; i < n; ++i)
				{
					if(snapshot.GetLocalIndex(groups_[j][i]) != -1)
						found[i] = 1;
				}

				MPI_Allreduce(MPI_IN_PLACE, found.data(), n, MPI_INT, MPI_SUM, snapshot.GetCommunicator());
				unsigned ntot = std::accumulate(found.begin(), found.end(), 0, std::plus<int>());
				if(ntot != n)
					throw std::invalid_argument(
						"ParticleCoordinateCV: Expected to find " + 
						to_string(n) + 
						" atoms in group " + to_string(j) + ", but only found " + 
						to_string(ntot) + "."
					);						
			}
		}


		//! Specifies whether the objective function is P2(n \cdot d) or 
		//  simply n \dcot d. 
		/*! 
		 * \param use Boolean on whether to use P2 objective function or not. 
		 */
		void UseP2(bool use) { p2_ = use; }

		//! Evaluate the CV.
		/*!
		 * \param snapshot Current simulation snapshot.
		 */
		void Evaluate(const Snapshot& snapshot) override
		{
			using namespace Eigen;

			// Get data from snapshot. 
			auto natoms = snapshot.GetNumAtoms();
			auto& comm = snapshot.GetCommunicator();

			// Initialize gradient.
			std::fill(_grad.begin(), _grad.end(), Vector3{0,0,0});
			_grad.resize(natoms, Vector3{0,0,0});

			// Get snapgrab and sync all atom info across processors. 
			auto& snap = Snapgrab::Instance();
			snap.SyncSnapshot(snapshot);
			auto& pos = snap.GetPositions();
			auto& mass = snap.GetMasses();

			// Initialize the Q-tensor.
			Matrix3 Q = Matrix3::Zero();
			
			int N = 0; // Number of selected groups.
			std::vector<int> selected; // Selected groups.

			// Store director (principal axis) associated with each
			// group of atoms which will be needed for derivatives later. 
			// Also, we need to define local gradient vector that can store 
			// matrices.
			std::vector<Vector3> directors;
			gradient_.resize(natoms);

			for(auto& group : groups_)
			{
				// Get center of mass. 
				std::vector<int> idx;
				snap.GetLocalIndices(group, &idx);
				Vector3 com = snap.CenterOfMass(idx);

				// Increment N now, and override later with proper number of selected groups.
				++N;

				// If not within region, skip.
				if(!IsWithinRegion(com))
					continue;

				selected.push_back(N-1);

				// Initialize inertial tensor. 
				Matrix3 I = Matrix3::Zero();

				// Go through individual local atoms.
				for(auto& id : idx)
				{
					auto x = snap.ApplyMinimumImage(pos[id] - com);
					auto& m = mass[id];
					I.noalias() += m*(Matrix3::Identity()*x.squaredNorm() - x*x.transpose());
				}

				// Perform EVD. The columns are the eigenvectors. 
				// SelfAdjoint solver sorts in ascending order. 
				SelfAdjointEigenSolver<Matrix3> solver;
				solver.computeDirect(I);
				const auto& eigvals = solver.eigenvalues();
				const auto& eigvecs = solver.eigenvectors();

				// Assign variables for clarity.
				auto l1 = eigvals[0], 
				     l2 = eigvals[1], 
				     l3 = eigvals[2];
				const auto& u1 = eigvecs.col(0), 
				            u2 = eigvecs.col(1), 
				            u3 = eigvecs.col(2);

				// HACK: Make sure the eigenvector is always pointing towards the first atom.
				// Collect first and second atom coordinates. 
	            const auto& x0 = pos[idx[0]], x1 = pos[idx[1]]; 
				Vector3 u = u1;
				if(u1.dot(snap.ApplyMinimumImage(x0 - x1).normalized()) < 0)
					u = -u1;

				// The smallest eigenvalue/eigenvector pair represent the principal axis 
				// of interest. We use them to construct Q-tensor.
				Q.noalias() += 1.5*u*u.transpose() - 0.5*Matrix3::Identity();

				// Get local processor ID's of atoms and add gradient.
				std::vector<int> lidx;
				snapshot.GetLocalIndices(group, &lidx);
				auto& lpos = snapshot.GetPositions();
				auto& lmass = snapshot.GetMasses();
				// Chain rule #1. du_i/dx_j
				for(auto& id : lidx)
				{
					auto x = snapshot.ApplyMinimumImage(lpos[id] - com);
					auto& m = lmass[id];
					gradient_[id].noalias() = 
						1./(l3 - l1)*m*u3*(x.dot(u3)*u + x.dot(u)*u3).transpose() + 
						1./(l2 - l1)*m*u2*(x.dot(u2)*u + x.dot(u)*u2).transpose();
				}

				// Store eigenvector.
				directors.push_back(u);
			}

			// Set N equal the actual number of selected groups.
			N = selected.size();

			// Normalize Q-tensor.
			Q /= N;

			// Since we have I on all processors, we don't need to reduce Q.
			// SelfAdjoint solver sorts in ascending order. 
			SelfAdjointEigenSolver<Matrix3> solver;
			solver.computeDirect(Q);
			const auto& eigvals = solver.eigenvalues();
			const auto& eigvecs = solver.eigenvectors();

			// Assign variables for clarity. 
			auto l1 = eigvals[0], 
			     l2 = eigvals[1], 
			     l3 = eigvals[2];
			const auto& n1 = eigvecs.col(0), 
			            n2 = eigvecs.col(1), 
			            n3 = eigvecs.col(2);
			// HACK: Make sure n3 is always in the upper half. 
			Vector3 n = n3; 
			if(n3[2] < 0)
				n = -n3;
			// Compute pentalty function (CV) from largest eigenvalue/vector pair. 
			auto dot = n.dot(d_);
			_val = dot;
			if(p2_)
				_val = 1.5*dot*dot - 0.5;

			// Complete gradient calculation. 
			for(int i = 0; i < N; ++i)	
			{
				// Get group principal axis. 
				auto& group = groups_[selected[i]];
				auto& u = directors[i]; 

				// Get local indices (again...)
				std::vector<int> idx;
				snapshot.GetLocalIndices(group, &idx);

				for(auto& id : idx)
				{
					auto coeff = (p2_) ? 3.0*dot : 1.0;

					// Chain rule #2. dn_k/du_i
					_grad[id].noalias() = 
						coeff*d_.transpose()*(
							1./(l3 - l1)*1.5/N*n1*(u.dot(n1)*n + u.dot(n)*n1).transpose() + 
							1./(l3 - l2)*1.5/N*n2*(u.dot(n2)*n + u.dot(n)*n2).transpose()
						)*gradient_[id];
				}
			}
		}

		void Serialize(Json::Value& json) const override
		{
			json["type"] = "NematicDirector";
			for(int i = 0; i < (int)groups_.size(); ++i)
				for(int j = 0; j < (int)groups_[i].size(); ++j)
				{
					json["groups"][i][j] = groups_[i][j];
				}

			json["director"][0] = d_[0];
			json["director"][1] = d_[1];
			json["director"][2] = d_[2];
			json["p2"] = p2_;

			if(restricted_)
			{
				json["restriction"]["min"] = rmin_;
				json["restriction"]["max"] = rmax_;
				switch(dim_)
				{
					case Dimension::x:
						json["restriction"]["dimension"] = "x";
						break;
					case Dimension::y:
						json["restriction"]["dimension"] = "y";
						break;
					case Dimension::z:
						json["restriction"]["dimension"] = "z";
						break;
				}
			}
		}

	};
}
