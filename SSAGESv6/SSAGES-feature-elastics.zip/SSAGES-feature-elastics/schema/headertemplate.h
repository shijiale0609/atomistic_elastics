#pragma once 

#include <iostream>

namespace SSAGES
{
	namespace JsonSchema
	{
		//INSERT_DEC_HERE
		
	};
}