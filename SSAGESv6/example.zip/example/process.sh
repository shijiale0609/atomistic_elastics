
awk 'NR>=534895 && NR<=535001'   F_out >>     F_5
awk 'NR>=1069895 && NR<=1070001' F_out >>     F_10
awk 'NR>=1604895 && NR<=1605001' F_out >>     F_15
awk 'NR>=2139895 && NR<=2140001' F_out >>     F_20
awk 'NR>=2674895 && NR<=2675001' F_out >>     F_25
awk 'NR>=3209895 && NR<=3210001' F_out >>     F_30
awk 'NR>=3744895 && NR<=3745001' F_out >>     F_35
awk "NR>=4279895 && NR<=4280001" F_out >>     F_40
awk "NR>=5349895 && NR<=5350001" F_out >>     F_50
awk "NR>=6419895 && NR<=6420001" F_out >>     F_60
awk "NR>=7489895 && NR<=7490001" F_out >>     F_70
awk "NR>=8559895 && NR<=8560001" F_out >>     F_80
awk "NR>=9629895 && NR<=9630001" F_out >>     F_90
awk "NR>=10699895 && NR<=10700001 " F_out >>     F_100

python ../../ABF_integrator.py  -i F_5    -o F_5
python ../../ABF_integrator.py  -i F_10   -o F_10
python ../../ABF_integrator.py  -i F_15   -o F_15
python ../../ABF_integrator.py  -i F_20   -o F_20
python ../../ABF_integrator.py  -i F_25   -o F_25
python ../../ABF_integrator.py  -i F_30   -o F_30
python ../../ABF_integrator.py  -i F_35   -o F_35
python ../../ABF_integrator.py  -i F_40   -o F_40
python ../../ABF_integrator.py  -i F_50   -o F_50
python ../../ABF_integrator.py  -i F_60   -o F_60
python ../../ABF_integrator.py  -i F_70   -o F_70
python ../../ABF_integrator.py  -i F_80   -o F_80
python ../../ABF_integrator.py  -i F_90   -o F_90
python ../../ABF_integrator.py  -i F_100  -o F_100



