#!/bin/csh
#$ -N test
#$ -m abe
#$ -t 1
#$ -q long@@whitmer
#$ -pe smp 4

module use /afs/crc.nd.edu/user/j/jshi1/modules/
module load boost/1.66
module load gcc/7.1.0

set args = `head -n $SGE_TASK_ID args.list | tail -n 1`
setenv OMP_NUM_THREADS 1

mpirun -np $NSLOTS /afs/crc.nd.edu/user/j/jshi1/SSAGESv6feature_elastics/build/ssages $args.json
