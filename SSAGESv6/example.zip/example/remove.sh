rm -rf *edr *cpt *xtc *trr *log *umbrella* *chkpt*


rm -rf F_out
rm -rf ABF-*
