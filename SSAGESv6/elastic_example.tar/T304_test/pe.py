import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt 
import math as m
import pandas as pd
from scipy.optimize import curve_fit
import numpy as np
import os
path = os.getcwd()

df = pd.read_csv("{}/F_final.txt".format(path), delimiter=" ")
R = 8.314e-3
T = 304.15
L = 5.71970
V = pow(L,3)
Na = 6.022e23
c = 1/(1-2*0.2)
edge = 0

def func(x,a):
    return a*pow(x,2)

F = df["F"]
F = F - min(F)
Z = np.array([0.0]*len(F))

for i in np.arange(0,len(F)):
      Z[i] = (F[i]+F[len(F)-i-1])/2

x = df["CV"][edge:len(F)-edge]/(L/2)
y = Z[edge:len(F)-edge] 

popt, pcov = curve_fit(func, x, y)

a = popt[0]
perr=np.sqrt(np.diag(pcov))
delta_a = perr[0]
yvals = func(x,a)

print ("fiting coefficient:",a)
print ("fiting coefficient delta:", delta_a)

plt.figure(figsize=(8,8))
plot1 = plt.plot(x, y, 's',markersize='5',label='original values')
plot2 = plt.plot(x, yvals, 'r',label='polyfit values')
plt.ylabel("F(kJ/mol)",size =20)
plt.xlabel("dn/dx",size =20)
plt.savefig("CV_F_curvefit.png")


k = a/(V/2*c)/Na*1e24

print ("elastic constant k: ", k)

dk = delta_a/(V/2*c)/Na*1e24  
print ("delta k:", dk)  

