import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt 
import math as m
import pandas as pd
from scipy.optimize import curve_fit
import numpy as np
import os
path = os.getcwd()

data_x, data_y, data_z  = [], [], []


i = 0


with open("kii_iter.txt") as f:
    for line in f:
        cols = line.split(',')
        i = i+1
        if i>=1:
            data_x.append(float(cols[0]))
            data_y.append(float(cols[1]))
            data_z.append(float(cols[2]))


plt.errorbar(data_x, data_y,data_z, marker = "s")
plt.ylim(0,20)
plt.ylabel("kii(pN)")
plt.xlabel("Iter")
plt.grid()
plt.savefig("kii_iter.png")
